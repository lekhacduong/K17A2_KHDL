a=input("nhap ten mon hang:     ")
b=int(input("nhap so luong :        "))
c=float(input("nhap so tien hang:     "))
d=int(b*c)
print("so tien phai tra la:  ",d,"vnd")

