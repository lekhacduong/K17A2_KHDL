a=(5-3)//2
b=(8-3)*(2-(1+1))
print(a)
print(b)