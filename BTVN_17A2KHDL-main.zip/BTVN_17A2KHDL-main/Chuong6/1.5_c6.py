#Bài 1.5
so_luong=int(input("Nhap so luong"))
don_gia=int(input("Don gia"))
thanh_tien=so_luong*don_gia
print("thanh tien=",so_luong,"=",don_gia,"=",thanh_tien)