#chiakeo
alice=121
bop=77
erick=109
tong=alice+bop+erick
a=tong%3
print ("so keo can dap vo la",a)