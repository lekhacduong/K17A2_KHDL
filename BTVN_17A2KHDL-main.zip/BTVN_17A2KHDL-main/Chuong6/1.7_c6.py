DoC=float(input("DoC"))
DoF=(9/5*DoC+32)
print("DoF=",DoF)