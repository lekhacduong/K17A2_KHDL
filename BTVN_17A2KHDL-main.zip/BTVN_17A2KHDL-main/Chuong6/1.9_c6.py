lai_suat_mot_nam=float(input("lai suat mot nam"))
so_tien=float(input("so tien gui"))
so_thang=int(input("so thang gui"))
tien_lai=so_tien*so_thang*(lai_suat_mot_nam/100/12)
tong_so_tien=tien_lai+so_tien
print(tien_lai)
print(tien_lai+so_tien)