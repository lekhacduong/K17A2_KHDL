a = int(input("nhap so a: "))
for i in range(a,0,-1):
    print(i)